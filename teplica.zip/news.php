<?php include_once ('header.php'); ?>
<section class="second-header news">
    <div class="shadow2"></div>
    <hr class="bottom-line">
    <hr class="bottom-line2">
</section>
<section class="section-block m-bg-none">
    <div class="section-title">
        <span><i class="upper">Новости</i> компании</span>
        <hr>
    </div>
    <div class="box2">
        <div class="n-news-container">
            <div class="news-slider" id="news-1">
                <div class="n-news-item">
                    <div class="n-news-item-img">
                        <div class="n-news-img-border"></div>
                        <div class="overflow">
                            <img src="assets/img/news2.jpg">
                        </div>
                    </div>
                    <div class="n-news-body">
                        <div class="n-news-text">
                            <p class="n-news-date">26.12.2017</p>
                            <p class="n-news-title">Happiness remainder remainder</p>
                            <div class="bottom-border">
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                            </div>
                            <hr>
                         </div>
                        <div class="n-news-button">
                            <div class="animated-height"></div>
                            <img src="assets/img/news-line.png">
                            <a href="#">Читать дальше</a>
                        </div>
                    </div>
                </div>

                <div class="n-news-item">
                    <div class="n-news-item-img">
                        <div class="n-news-img-border"></div>
                        <div class="overflow">
                            <img src="assets/img/news2.jpg">
                        </div>
                    </div>
                    <div class="n-news-body">
                        <div class="n-news-text">
                            <p class="n-news-date">26.12.2017</p>
                            <p class="n-news-title">Happiness remainder remainder</p>
                            <div class="bottom-border">
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                            </div>
                            <hr>
                        </div>
                        <div class="n-news-button">
                            <div class="animated-height"></div>
                            <img src="assets/img/news-line.png">
                            <a href="#">Читать дальше</a>
                        </div>
                    </div>
                </div>

                <div class="n-news-item">
                    <div class="n-news-item-img">
                        <div class="n-news-img-border"></div>
                        <div class="overflow">
                            <img src="assets/img/news2.jpg">
                        </div>
                    </div>
                    <div class="n-news-body">
                        <div class="n-news-text">
                            <p class="n-news-date">26.12.2017</p>
                            <p class="n-news-title">Happiness remainder remainder</p>
                            <div class="bottom-border">
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                            </div>
                            <hr>
                        </div>
                        <div class="n-news-button">
                            <div class="animated-height"></div>
                            <img src="assets/img/news-line.png">
                            <a href="#">Читать дальше</a>
                        </div>
                    </div>
                </div>
                <div class="n-news-item">
                    <div class="n-news-item-img">
                        <div class="n-news-img-border"></div>
                        <div class="overflow">
                            <img src="assets/img/news2.jpg">
                        </div>
                    </div>
                    <div class="n-news-body">
                        <div class="n-news-text">
                            <p class="n-news-date">26.12.2017</p>
                            <p class="n-news-title">Happiness remainder remainder</p>
                            <div class="bottom-border">
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                                <p>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentime for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length</p>
                            </div>
                            <hr>
                        </div>
                        <div class="n-news-button">
                            <div class="animated-height"></div>
                            <img src="assets/img/news-line.png">
                            <a href="#">Читать дальше</a>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="news-paggination">
                <div class="prev-next">
                    <div class="prev"></div>
                    <div class="next"></div>
                </div>
                <div class="n-news-digits">
                    <a data-id="1" href="" class="active">1</a>
                    <a data-id="1" href="">2</a>
                    <a data-id="1" href="">3</a>
                    <a data-id="1" href="">4</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include_once ('footer.php'); ?>
