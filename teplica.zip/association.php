<?php include_once ('header.php'); ?>
<section class="second-header about assoc">
    <div class="shadow2"></div>
    <div class="header-container mobile-none">
        <div class="header-container-item">
            <p class="light">Мы трудимся радипроцветания сельского хозяйства Казахстана!</p>
            <hr>
            <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, </span>
        </div>
    </div>
    <div class="header-container mobile-visible">
        <div class="header-container-item">
            <h2>АССОЦИАЦИЯ ТЕПЛИЦ </h2>
            <h1>КАЗАХСТАНА</h1>
        </div>
        <div class="header-container-item-2">
            <ul>
                <li><h3>Мы трудимся радипроцветания</h3></li>
                <li><h2>сельского хозяйства Казахстана!</h2></li>
            </ul>
        </div>
    </div>
    <hr class="bottom-line">
    <hr class="bottom-line2">
</section>

<section class="assoc-block">
    <div class="box2">
        <div class="about-box">
            <div class="assoc-item">
                <div class="section-title">
                    <span>Тепличные<i class="upper"> комбинаты</i></span>
                    <hr>
                </div>
                <div class="shodow-body comb" id="combinat-1">
                    <table class="tg">
                        <tr>
                            <td class="td1">ТОО «Тепличные комбинаты»</td>
                            <td class="td2">10 000 км</td>
                            <td class="td3">кукуруза</td>
                        </tr>
                        <tr>
                            <td>ТОО «Тепличные комбинаты»</td>
                            <td>25 000 км</td>
                            <td>пшеница томат</td>
                        </tr>
                        <tr>
                            <td>ТОО «Тепличные комбинаты»</td>
                            <td>10 000 км</td>
                            <td>кукуруза</td>
                        </tr>
                        <tr>
                            <td>ТОО «Тепличные комбинаты»</td>
                            <td>25 000 км</td>
                            <td>пшеница томат</td>
                        </tr>
                        <tr>
                            <td>ТОО «Тепличные комбинаты»</td>
                            <td>10 000 км</td>
                            <td>кукуруза</td>
                        </tr>
                        <tr>
                            <td>ТОО «Тепличные комбинаты»</td>
                            <td>25 000 км</td>
                            <td>пшеница томат</td>
                        </tr>
                        <tr>
                            <td>ТОО «Тепличные комбинаты»</td>
                            <td>10 000 км</td>
                            <td>кукуруза</td>
                        </tr>
                        <tr>
                            <td>ТОО «Тепличные комбинаты»</td>
                            <td>25 000 км</td>
                            <td>пшеница томат</td>
                        </tr>
                        <tr>
                            <td>ТОО «Тепличные комбинаты»</td>
                            <td>10 000 км</td>
                            <td>кукуруза</td>
                        </tr>
                    </table>
                </div>
                <div class="paggination p-left">
                    <a data-id="1" href="#" class="active">1</a>
                    <a data-id="1" href="#">2</a>
                    <a data-id="1" href="#">3</a>
                    <a data-id="1" href="#">4</a>
                </div>
            </div>
            <div class="assoc-item">
                <div class="section-title">
                    <span><i class="upper">Поставщики </i> тепличной технологии</span>
                    <hr>
                </div>
                <div class="shodow-body post" id="postavshik-1">
                    <div class="assoc-item2">
                        <div class="item2-flex">
                            <div class="item2-img">
                                <img src="assets/img/assoc.jpg">
                            </div>
                            <div class="item2-text">
                                <p>ТОО «Тепличные комбинаты»</p>
                            </div>
                        </div>
                        <div class="item2-body">
                            <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five </span>
                        </div>
                    </div>

                    <div class="assoc-item2">
                        <div class="item2-flex">
                            <div class="item2-img">
                                <img src="assets/img/assoc2.jpg">
                            </div>
                            <div class="item2-text">
                                <p>ТОО «Тепличные комбинаты»</p>
                            </div>
                        </div>
                        <div class="item2-body">
                            <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release</span>
                        </div>
                    </div>

                    <div class="assoc-item2">
                        <div class="item2-flex">
                            <div class="item2-img">
                                <img src="assets/img/assoc3.jpg">
                            </div>
                            <div class="item2-text">
                                <p>ТОО «Тепличные комбинаты»</p>
                            </div>
                        </div>
                        <div class="item2-body">
                            <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining</span>
                        </div>
                    </div>
                </div>

                <div class="paggination p-right">
                    <a data-id="1" href="#" class="active">1</a>
                    <a data-id="1" href="#">2</a>
                    <a data-id="1" href="#">3</a>
                    <a data-id="1" href="#">4</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="about2">
    <div class="shadow-top"><hr></div>
    <div class="about2-box">
        <span>Участвуйте в нашей ежегодной </span>
        <p>международной выставке! </p>
        <a href="exhibition.php"><div class="pad">Подробнее</div> </a>
        <img src="assets/img/about-6.png" class="about-img">
    </div>
    <div class="shadow-bottom"><hr></div>
</section>

<?php include_once ('slider_and_news.php'); ?>
<?php include_once ('footer.php'); ?>
