<!--news-->
<section class="news mobile-none">
    <div class="section-title">
        <span><i class="upper">Новости</i> компании</span>
        <hr>
    </div>
    <div class="news-box">
        <div class="news-box-margin">
            <div class="news-item n1">
                <div class="news-header">
                    <div class="news-img">
                        <div class="overflow">
                            <img src="assets/img/news.jpg">
                        </div>
                    </div>
                    <div class="news-date">
                        <p>26.12.2017</p>
                    </div>
                </div>
                <div class="news-body">
                    <p class="news-title">Happiness remainder remainder</p>
                    <span>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off</span>
                    <a href="news-full.php">Читать дальше</a>
                </div>
            </div>

            <div class="news-item n2">
                <div class="news-header">
                    <div class="news-img">
                        <div class="overflow">
                            <img src="assets/img/news.jpg">
                        </div>
                    </div>
                    <div class="news-date">
                        <p>26.12.2017</p>
                    </div>
                </div>
                <div class="news-body">
                    <p class="news-title">Happiness remainder remainder</p>
                    <span>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off</span>
                    <a href="news-full.php">Читать дальше</a>
                </div>
            </div>

            <div class="news-item n3">
                <div class="news-header">
                    <div class="news-img">
                        <div class="overflow">
                            <img src="assets/img/news.jpg">
                        </div>
                    </div>
                    <div class="news-date">
                        <p>26.12.2017</p>
                    </div>
                </div>
                <div class="news-body">
                    <p class="news-title">Happiness remainder remainder</p>
                    <span>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off</span>
                    <a href="news-full.php">Читать дальше</a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="mobile-news mobile-visible ">
    <div class="slider-box">
        <div class="box-owl">
            <div class="owl-left m-left">
                <img src="assets/img/part/r-m.png">
            </div>
            <div class="owl-center m-news">
                <div class="news-item">
                    <div class="news-header">
                        <div class="news-img">
                            <div class="overflow">
                                <img src="assets/img/news.jpg">
                            </div>
                        </div>
                        <div class="news-date">
                            <p>26.12.2017</p>
                        </div>
                    </div>
                    <div class="news-body">
                        <p class="news-title">Happiness remainder remainder</p>
                        <span>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off</span>
                        <a href="news-full.php">Читать дальше</a>
                    </div>
                </div>

                <div class="news-item">
                    <div class="news-header">
                        <div class="news-img">
                            <div class="overflow">
                                <img src="assets/img/news.jpg">
                            </div>
                        </div>
                        <div class="news-date">
                            <p>26.12.2017</p>
                        </div>
                    </div>
                    <div class="news-body">
                        <p class="news-title">Happiness remainder remainder</p>
                        <span>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off</span>
                        <a href="news-full.php">Читать дальше</a>
                    </div>
                </div>

                <div class="news-item">
                    <div class="news-header">
                        <div class="news-img">
                            <div class="overflow">
                                <img src="assets/img/news.jpg">
                            </div>
                        </div>
                        <div class="news-date">
                            <p>26.12.2017</p>
                        </div>
                    </div>
                    <div class="news-body">
                        <p class="news-title">Happiness remainder remainder</p>
                        <span>for off. Celebrated delightfu l an especially increasing instrument am. Secure shy favour length all twenty denote. Sentimefor off</span>
                        <a href="news-full.php">Читать дальше</a>
                    </div>
                </div>
            </div>
            <div class="owl-right m-right">
                <img src="assets/img/part/r-m.png">
            </div>

        </div>
    </div>
</section>
<!--slider-->
<section class="slider">
    <div class="section-title">
        <span>Наши<i class="upper white"> Партнеры</i></span>
        <hr>
    </div>
    <div class="slider-box">
        <div class="box-owl">
            <div class="owl-left o-left">
                <img src="assets/img/part/l.png">
            </div>
            <div class="owl-center p-slider">
                <div class="owl-img">
                    <img src="assets/img/part/1.png">
                </div>
                <div class="owl-img">
                    <img src="assets/img/part/3.png">
                </div>
                <div class="owl-img">
                    <img src="assets/img/part/2.png">
                </div>
                <div class="owl-img">
                    <img src="assets/img/part/1.png">
                </div>
                <div class="owl-img">
                    <img src="assets/img/part/3.png">
                </div>
                <div class="owl-img">
                    <img src="assets/img/part/2.png">
                </div>
            </div>
            <div class="owl-right o-right">
                <img src="assets/img/part/l.png">
            </div>

        </div>
    </div>
</section>